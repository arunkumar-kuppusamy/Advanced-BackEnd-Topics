package br.com.visualizarcompartilhar.bsad;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.Base64;
import com.itextpdf.tool.xml.XMLWorker;
import com.itextpdf.tool.xml.XMLWorkerFontProvider;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import com.itextpdf.tool.xml.css.CssFile;
import com.itextpdf.tool.xml.css.StyleAttrCSSResolver;
import com.itextpdf.tool.xml.html.CssAppliers;
import com.itextpdf.tool.xml.html.CssAppliersImpl;
import com.itextpdf.tool.xml.html.Tags;
import com.itextpdf.tool.xml.parser.XMLParser;
import com.itextpdf.tool.xml.pipeline.css.CSSResolver;
import com.itextpdf.tool.xml.pipeline.css.CssResolverPipeline;
import com.itextpdf.tool.xml.pipeline.end.PdfWriterPipeline;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipeline;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipelineContext;

/**
 * 
 */
public class VISUAL {

	private static final Logger LOGGER = LoggerFactory.getLogger(VisualizarCompartilharBSAD.class);
	
	public final int TAMANHO_BUFFER_BYTES = 4096; //4kb
	public final String webInfFolder = "\\WEB-INF\\pages\\templates\\";
	public final String rootWebInfFolder = new File("src").getAbsolutePath() + webInfFolder;
	public final String caminhoCSS = "\\contratacao\\default.css";
	public final String caminhoPDF = "\\output\\comprovante-contratacao-bsad.pdf";
	public final String caminhoPROPS = "\\contratacao\\comprovante.properties";

	/*
	 * Gerar um ZIP de um arquivo HTML novo.
	 */
	  public final String templateComprovanteAPP = "\\contratacao\\app-comprovante-contratacao.html";
	  public final String templateTermosAceite = "\\contratacao\\app-termos-aceite.html";
	  public final String templateTermosAceite2 = "\\contratacao\\app-termos-aceite-opcao2.html";
	  public final String caminhoZIP = "\\output\\comprovante-contratacao-bsad.zip";

	/*
	 * Gerar um ZIP de um arquivo PDF Existente
	 */
	  public final String pdfCondicoesGerais = "\\contratacao\\appremiavel-condicoes-gerais.pdf";
	  //public final String zipCondicoesGerais = "\\output\\comprovante-fixo-bsad.zip";

	public String gerarArquivosFisicos(String arquivoPDF, FileOutputStream caminhoPdfZip) throws Exception {
		/*
		 * Gera um ZIP apartir de um PDF existente.
		 *
		 * Utilize [caminhoPdfZip] para ver o arquivo fisico
		 * Utilize [null] para NAO gerar o arquivo fisico, somente o buffer.
		 */
		String zipBase64 = null;
		try {
			InputStream inputStreamEntrada = new FileInputStream(rootWebInfFolder + arquivoPDF);
			byte[] buffer = new byte[TAMANHO_BUFFER_BYTES];
			int bytesRead;
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			while ((bytesRead = inputStreamEntrada.read(buffer)) != -1) {
				byteArrayOutputStream.write(buffer, 0, bytesRead);
			}
			inputStreamEntrada.close();
			/*
			 * Gerar ZIP em memoria bufferizado
			 */
			zipBase64 = gerarZIP(byteArrayOutputStream, caminhoPdfZip);//caminhoPdfZip ou null
		}catch(Exception e) {
			throw new Exception(e);
		}
		return zipBase64;
	}

	public String gerarArquivos(String caminhoHTMLTemplate, ContratacaoAppViewBean contratacaoAppViewBean) throws Exception {

		/*
		 * Cria um arquivo PDF que sera utilizado.
		 * 
		 * Utilize [caminhoPDFSaida] para ver o arquivo fisico
		 * Utilize [pdfByteArrayStream] para NAO gerar o arquivo fisico, somente o buffer.
		 */
		//JOGA NA PASTA DO SERVIDOR : C:/runtimes/wlp-clean/usr/servers/defaultServer/src/WEB-INF/pages/templates/output/
		FileOutputStream caminhoPDFSaida = new FileOutputStream(new File(rootWebInfFolder + caminhoPDF));
		ByteArrayOutputStream pdfByteArrayStream = new ByteArrayOutputStream();
		Document document = new Document();
		PdfWriter writer = PdfWriter.getInstance(document, caminhoPDFSaida);//pdfByteArrayStream OU caminhoPDFSaida
		writer.setInitialLeading(12.5f);
		document.open();

		/*
		 * Configura um arquivo de estilos para o PDF
		 */
		CSSResolver cssResolver = new StyleAttrCSSResolver();
		CssFile cssFile = XMLWorkerHelper.getInstance().getCSS(new FileInputStream(rootWebInfFolder + caminhoCSS));
		cssResolver.addCss(cssFile);

		/*
		 * Carrega fontes customizadas para o PDF
		 */
		//https://developers.itextpdf.com/examples/xml-worker-itext5/xml-worker-examples#711-d06_parsehtmlfonts.java
		XMLWorkerFontProvider fontProvider = new XMLWorkerFontProvider();
		fontProvider.register(webInfFolder + "\\fontes\\newjune-book-webfont.ttf");
		fontProvider.register(webInfFolder + "\\fontes\\newjune-medium-webfont.ttf");
		fontProvider.register(webInfFolder + "\\fontes\\newjune-bold-webfont.ttf");
		CssAppliers cssAppliers = new CssAppliersImpl(fontProvider);
		HtmlPipelineContext htmlContext = new HtmlPipelineContext(cssAppliers);
		htmlContext.setTagFactory(Tags.getHtmlTagProcessorFactory());
		PdfWriterPipeline pdf = new PdfWriterPipeline(document, writer);
		HtmlPipeline html = new HtmlPipeline(htmlContext, pdf);
		CssResolverPipeline css = new CssResolverPipeline(cssResolver, html);

		/*
		 * Alterar valores no HTML existente.
		 */
		StringBuffer arquivoOriginal = carregaArquivosFisicos(rootWebInfFolder + caminhoHTMLTemplate);
		StringBuffer arquivoNovosValores = replaceConteudo(arquivoOriginal, contratacaoAppViewBean);
		InputStream inputStream = new ByteArrayInputStream( arquivoNovosValores.toString().getBytes());

		/*
		 * Cria o PDF com o XMLParser.parser(), usando o HTML.
		 */
		XMLWorker worker = new XMLWorker(css, true);
		XMLParser p = new XMLParser(worker);
		p.parse(inputStream);
		document.close();

		/*
		 * Gera Stream 64 bytes do PDF
		 * Gera um Zip do PDF
		 * Gera um Stream 64 bytes do Zip
		 *
		 * Utilize [caminhoZIP] para ver o arquivo fisico
		 * Utilize [null] para NAO gerar o arquivo fisico, somente o buffer.
		 */
		//FileOutputStream caminhoZIPDinamic = new FileOutputStream(new File(rootFolder + caminhoZIP));
		String zipBase64 = gerarZIP(pdfByteArrayStream, null);//caminhoZIPDinamic ou null

		/*
		 * Gera um ZIP apartir de um PDF existente.
		 *
		 * Utilize [caminhoZIPFisico] para ver o arquivo fisico
		 * Utilize [null] para NAO gerar o arquivo fisico, somente o buffer.
		 */
		//FileOutputStream caminhoZIPFisico = new FileOutputStream(new File(rootFolder + caminhoZIPFixo));
		//String caminhoPDFOriginal = rootWebInfFolder + pdfCondicoesGerais;
		//String zipBase64PDFFisico = gerarArquivosFisicos(caminhoPDFOriginal, null);//caminhoZIPFisico ou  null
		//loggingAnaliseBuffer(zipBase64PDFFisico, null, null);//pdf fisco

		loggingAnaliseBuffer(zipBase64, pdfByteArrayStream, arquivoNovosValores);

		return zipBase64;
	}

	public void loggingAnaliseBuffer(String zipBase64, ByteArrayOutputStream pdf, StringBuffer htmlString) throws IOException {
		/*
		 * Metodo utilitario para visualizar os buffers criados
		 * Loggggging para analise
		 */
		if(htmlString!=null && htmlString.length() > 0) {
			byte[] byteArray = htmlString.toString().getBytes();
			String htmlBase64 = Base64.encodeBytes(byteArray);
			LOGGER.error("\nHTML Tamanho: " + htmlBase64.length() + " caracteres.\n" + htmlBase64.replaceAll("\n", ""));
		}
		if(pdf!=null) {
			byte[] array = pdf.toByteArray();
				  pdf.flush();
				  pdf.close();
			String pdfBase64 = Base64.encodeBytes(array);
			LOGGER.error("\nPDF Tamanho: " + pdfBase64.length() + " caracteres.\n" + pdfBase64.replaceAll("\n", ""));
		}
		if (zipBase64!=null && zipBase64.length() > 500) {//maior que somente o cabecalho
			LOGGER.error("\nZIP Tamanho: " + zipBase64.length() + " caracteres.\n" + zipBase64.replaceAll("\n", ""));
		}
	}

	/*
	 * Procura por token no HTML e substitui por valores reais da aplicacao.
	 */
	public StringBuffer replaceConteudo(StringBuffer htmlReplaceConteudo, ContratacaoAppViewBean contratacaoAppViewBean) throws Exception {
		
		Map<String, String> map = new HashMap<String, String>();
		/*
		 * Uma opcao para colocar valores dinamicos no HTML Fisico.
		 * Defini % como um caracter de identificacao.
		 *
		 */
		final String properties = rootWebInfFolder + caminhoPROPS;
		Map<String, String> propertiesMap = loadMappingProperties(properties);
		for (Entry<String, String> entry : propertiesMap.entrySet()) {
			LOGGER.error( "["+entry.getKey() +" = "+ entry.getValue() +"]" );
			map.put(entry.getKey(), entry.getValue());
		}

		//Valores que nao podemos colocar nos properties
		SimpleDateFormat simple = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		map.put("%DATA_CONTRATACAO", simple.format(new Date()));
		map.put("%ROOT_FOLDER", webInfFolder.replace("\\", "/"));
		
		map.put("%SEGURO_CONTRATADO", "ACIDENTES PESSOAIS PREMI&Aacute;VEL");
		map.put("%PROTOCOLO", "01234567890000000000");
		map.put("%DATA_CONTRATACAO", "01/01/2019 00:12:34");
		map.put("%QTDE_MODULOS_CONTRATADOS", "1");
		map.put("%COBERTURA_MODULOS", "50.000,00");
		map.put("%SEGURADO_NOME", "FLAVIA SILVA FERRAO");
		map.put("%SEGURADO_CPF", "061.863.500-00");
		map.put("%SEGURADO_DTNASC", "25/03/1974");
		map.put("%SEGURADO_PROFISSAO", "69 - Analista de Sistemas");
		map.put("%SEGURADO_RENDA", "De 8.0001 a 10.000");
		map.put("%SEGURADO_SEXO ", "FEMININO");
		map.put("%SEGURADO_CEP", "20261-105");
		map.put("%SEGURADO_RUA", "R BARAO DE ITAPAGIPE");
		map.put("%SEGURADO_NR", "329");
		map.put("%SEGURADO_COMPLEMENTO", "Casa 3");
		map.put("%SEGURADO_BAIRRO", "TIJUCA");
		map.put("%SEGURADO_CIDADE", "RIO DE JANEIRO");
		map.put("%SEGURADO_UF", "RJ");
		map.put("%SEGURADO_TELEFONE", "(21) 96450-1246");
		map.put("%SEGURADO_EMAIL", "contato@ebix.com");
		map.put("%SEGURADO_BANCO", "237");
		map.put("%SEGURADO_AGENCIA", "3861");
		map.put("%SEGURADO_CONTA", "553333-3");
		map.put("%SEGURADO_TPCONTA", "Conta Corrente");
		map.put("%PREMIO_ESCOLHIDO", "8,41");
		map.put("%PREMIO_IOF", "0,03");
		map.put("%PREMIO_TOTAL", "8,44");
		map.put("%PREMIO_PLANO", "Pr&ecirc;mio Mensal");
		
		/*
		 * Replace conteudo no HTML com os Dados da Contratacao
		 * Nos casos abaixo posso ter 1 ou ate 5 beneficiarios, logo tive que criar o html neste metodo.
		 */
		if(contratacaoAppViewBean != null) {
			List<BeneficiarioVO> listaOriginal = contratacaoAppViewBean.getBeneficiarios();
			if(listaOriginal == null || listaOriginal.isEmpty()) {
				map.put("%BENEF_CABECALHO", "<tr><td><p><strong>N�o informado</strong></p></td></tr>"); }
			else {
				map.put("%BENEF_CABECALHO", "<tr><td><p><strong>Nome</strong></p></td><td><p><strong>Parentesco</strong></p></td><td><p><strong>Percentual</strong></p></td></tr>");
				int i = 0;
				for (BeneficiarioVO beneficiario : listaOriginal) {
					map.put("%BENEF_"+ ++i +"_NOME", "<tr><td><p>"+beneficiario.getNome()+"</p></td><td><p>"+beneficiario.getDescGrauParentesco()+"</p></td><td><p>"+beneficiario.getPercentualParticipacao()+" %</p></td></tr>");
				}
			}
		}
		
		for (Entry<String, String> entry : map.entrySet()) {
			//Note that backslashes (\) and dollar signs ($) in the replacement string may cause the results to be different 
			htmlReplaceConteudo = new StringBuffer(htmlReplaceConteudo.toString().replaceAll(entry.getKey(), entry.getValue()));
		}
		LOGGER.error(htmlReplaceConteudo.toString());
		return htmlReplaceConteudo;
	}

	private Map<String, String> loadMappingProperties(String properties) throws Exception {
		
		Map<String, String> map = new HashMap<String, String>();
		try {
			Properties props = new Properties();
			FileInputStream file;
			file = new FileInputStream(properties);
			props.load(file);
			Enumeration<String> enums = (Enumeration<String>) props.propertyNames();
		    while (enums.hasMoreElements()) {
		      String key = enums.nextElement();
		      String value = props.getProperty(key);
		      map.put(key, value);
		    }
		} catch (Exception e) {
			throw new Exception(e);
		}
		return map;
	}

	private StringBuffer carregaArquivosFisicos(String caminhoHTML) throws Exception {
		StringBuffer buffer = new StringBuffer();
		try {
			InputStream inHTML = new FileInputStream(caminhoHTML);
			int content;
			while ((content = inHTML.read()) != -1) {
				buffer.append((char)content);
			}
			inHTML.close();
		} catch (Exception e) {
			throw new Exception(e);
		}
		return buffer;
	}

	/**
	 * Gerar ZIP apartir de um PDF Bufferizado
	 * @param ByteArrayOutputStream byteArrayOutputStream
	 * @return ByteArrayOutputStream byteArrayOutputStream
	 * @throws Exception
	 */
	private String gerarZIP(ByteArrayOutputStream byteArrayOutputStream, FileOutputStream caminhoZip) throws Exception {

		ByteArrayOutputStream destinoBuffer = null;
		String zipBase64 = null;
		try {
			if(byteArrayOutputStream.size() == 0) {
				LOGGER.error("\nZIP : Foi escolhido a saida fisica do PDF, logo o buffer zip64bits nao sera gerado, altere em PdfWriter.getInstance(document, bufferarrayoutputstream);");
			}
			final int TAMANHO_BUFFER_BYTES = 4096; // 4kb
			InputStream inputStreamEntrada = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
			BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStreamEntrada, TAMANHO_BUFFER_BYTES);

			ZipOutputStream zipOutputStream = null;
			if(caminhoZip!=null) {
				BufferedOutputStream destinoArquivo = new BufferedOutputStream(caminhoZip);
				// Use {destinoArquivo} para visualiza-lo na pasta src.
				zipOutputStream = new ZipOutputStream(destinoArquivo);
			}else {
				destinoBuffer = new ByteArrayOutputStream();
				// Use {destinoBuffer} para gerar Internamente.
				zipOutputStream = new ZipOutputStream(destinoBuffer);
			}

			// Defina um nome de como o pdf vai ficar dentro do zip, invisivel ao cliente.
			ZipEntry entry = new ZipEntry("comprovante_bradesco.pdf");
			if (!entry.isDirectory()) {
				zipOutputStream.putNextEntry(entry);
			}
			int cont;
			byte[] dados = new byte[TAMANHO_BUFFER_BYTES];
			while ((cont = bufferedInputStream.read(dados, 0, TAMANHO_BUFFER_BYTES)) != -1) {
				zipOutputStream.write(dados, 0, cont);
			}

			inputStreamEntrada.close();
			bufferedInputStream.close();
			zipOutputStream.close();
		} catch (Exception e) {
			throw new Exception(e);
		}

		/*
		 * Converte para String o Buffer Zip Array.
		 */
		if (destinoBuffer!=null) {
			byte[] array = destinoBuffer.toByteArray();
			zipBase64 = Base64.encodeBytes(array);
		} else {
			LOGGER.error("\nZIP: Foi escolhida a saida para a pasta fisica, arquivo gerado em: " + rootWebInfFolder);
		}

		return zipBase64;
	}

}
