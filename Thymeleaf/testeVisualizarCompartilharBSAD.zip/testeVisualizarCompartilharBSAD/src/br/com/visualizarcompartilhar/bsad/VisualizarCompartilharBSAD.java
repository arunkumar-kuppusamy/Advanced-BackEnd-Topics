package br.com.visualizarcompartilhar.bsad;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.codec.Base64;
import com.itextpdf.tool.xml.XMLWorker;
import com.itextpdf.tool.xml.XMLWorkerFontProvider;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import com.itextpdf.tool.xml.css.CssFile;
import com.itextpdf.tool.xml.css.StyleAttrCSSResolver;
import com.itextpdf.tool.xml.html.CssAppliers;
import com.itextpdf.tool.xml.html.CssAppliersImpl;
import com.itextpdf.tool.xml.html.Tags;
import com.itextpdf.tool.xml.parser.XMLParser;
import com.itextpdf.tool.xml.pipeline.css.CSSResolver;
import com.itextpdf.tool.xml.pipeline.css.CssResolverPipeline;
import com.itextpdf.tool.xml.pipeline.end.PdfWriterPipeline;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipeline;
import com.itextpdf.tool.xml.pipeline.html.HtmlPipelineContext;

import br.com.visualizarcompartilhar.bean.Beneficiario;
import br.com.visualizarcompartilhar.bean.DadosSeguradoVO;
import br.com.visualizarcompartilhar.bean.MockDadosSegurado;

public class VisualizarCompartilharBSAD {

	//private final long serialVersionUID = 1L;

	final int TAMANHO_BUFFER_BYTES = 4096; // 4kb
	final String rootFolder = new File("src").getAbsolutePath();
	final String caminhoCSS = "\\META-INF\\templates\\contratacao\\default.css";
	final String caminhoPDF = "\\META-INF\\templates\\output\\comprovante-contratacao-bsad.pdf";

	/*
	 * Gerar um ZIP de um arquivo HTML novo.
	 */
	  final String caminhoCONT = "\\META-INF\\templates\\contratacao\\app-comprovante-contratacao.html;";
	  final String caminhoHTML = "\\META-INF\\templates\\contratacao\\app-comprovante-contratacao.html";
	  final String caminhoZIP = "\\META-INF\\templates\\output\\comprovante-contratacao-bsad.zip";

	/*
	 * Gerar um ZIP de um arquivo PDF Existente
	 */
	  final String caminhoPDFFixo = "\\META-INF\\templates\\contratacao\\appremiavel-condicoes-gerais.pdf";
	  final String caminhoZIPFixo = "\\META-INF\\templates\\output\\comprovante-fixo-bsad.zip";


	public static void main(String[] args) throws IOException, DocumentException {

		try {
			System.out.println("--> Iniciando Visualizar e Compartihar.");
			VisualizarCompartilharBSAD salvar = new VisualizarCompartilharBSAD();
			String pdfBase64 = salvar.gerarArquivos();

			/*
			 * Enviar a tela a variavel pdfBase64, e setar num inputHidden obrigatoriamente com o identificador [id=pdfBase64].
			 */
				//<input type="hidden" id="pdfBase64" value="${pdfBase64}" />
			/*
			 * Criar dois botoes nesta tela
			*/
				//<button onclick="javascript:enviarPDFEmbarcada('visualizarComprovante');">Visualizar</button>
				//<button onclick="javascript:enviarPDFEmbarcada('baixarComprovante');">Baixar/Compartilhar</button>

			System.out.println("\n--> Saindo Visualizar e Compartihar.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String gerarArquivosFisicos(String arquivoPDF, FileOutputStream caminhoPdfZip) throws Exception {
		/*
		 * Gera um ZIP apartir de um PDF existente.
		 *
		 * Utilize [caminhoPdfZip] para ver o arquivo fisico
		 * Utilize [null] para NAO gerar o arquivo fisico, somente o buffer.
		 */
		String zipBase64 = null;
		try {
			InputStream inputStreamEntrada = new FileInputStream(arquivoPDF);
			byte[] buffer = new byte[TAMANHO_BUFFER_BYTES];
			int bytesRead;
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			while ((bytesRead = inputStreamEntrada.read(buffer)) != -1) {
				byteArrayOutputStream.write(buffer, 0, bytesRead);
			}
			inputStreamEntrada.close();
			/*
			 * Gerar ZIP em memoria bufferizado
			 */
			zipBase64 = gerarZIP(byteArrayOutputStream, caminhoPdfZip);//caminhoPdfZip ou null
		}catch(Exception e) {
			throw new Exception(e);
		}
		return zipBase64;
	}

	public String gerarArquivos() throws Exception {

		/*
		 * Cria um arquivo PDF que sera utilizado.
		 * 
		 * Utilize [caminhoPDFSaida] para ver o arquivo fisico
		 * Utilize [pdfByteArrayStream] para NAO gerar o arquivo fisico, somente o buffer.
		 */
		FileOutputStream caminhoPDFSaida = new FileOutputStream(new File(rootFolder + caminhoPDF));
		ByteArrayOutputStream pdfByteArrayStream = new ByteArrayOutputStream();
		Document document = new Document();
		PdfWriter writer = PdfWriter.getInstance(document, caminhoPDFSaida);//pdfByteArrayStream OU fileOutputPDF
		writer.setInitialLeading(12.5f);
		document.open();

		/*
		 * Configura um arquivo de estilos para o PDF
		 */
		CSSResolver cssResolver = new StyleAttrCSSResolver();
		CssFile cssFile = XMLWorkerHelper.getInstance().getCSS(new FileInputStream(rootFolder + caminhoCSS));
		cssResolver.addCss(cssFile);

		/*
		 * Carrega fontes customizadas para o PDF
		 */
		//https://developers.itextpdf.com/examples/xml-worker-itext5/xml-worker-examples#711-d06_parsehtmlfonts.java
		XMLWorkerFontProvider fontProvider = new XMLWorkerFontProvider();
		fontProvider.register("\\META-INF\\templates\\fontes\\newjune-book-webfont.ttf");
		fontProvider.register("\\META-INF\\templates\\fontes\\newjune-medium-webfont.ttf");
		fontProvider.register("\\META-INF\\templates\\fontes\\newjune-bold-webfont.ttf");
		CssAppliers cssAppliers = new CssAppliersImpl(fontProvider);
		HtmlPipelineContext htmlContext = new HtmlPipelineContext(cssAppliers);
		htmlContext.setTagFactory(Tags.getHtmlTagProcessorFactory());
		PdfWriterPipeline pdf = new PdfWriterPipeline(document, writer);
		HtmlPipeline html = new HtmlPipeline(htmlContext, pdf);
		CssResolverPipeline css = new CssResolverPipeline(cssResolver, html);

		/*
		 * Alterar valores no HTML existente.
		 */
		StringBuffer arquivoOriginal = carregaArquivosFisicos(rootFolder + caminhoHTML);
		StringBuffer arquivoNovosValores = replaceConteudo(arquivoOriginal);
		InputStream inputStream = new ByteArrayInputStream( arquivoNovosValores.toString().getBytes());

		/*
		 * Cria o PDF com o XMLParser.parser(), usando o HTML.
		 */
		XMLWorker worker = new XMLWorker(css, true);
		XMLParser p = new XMLParser(worker);
		p.parse(inputStream);
		//inputStream.close();
		document.close();

		/*
		 * Gera Stream 64 bytes do PDF
		 * Gera um Zip do PDF
		 * Gera um Stream 64 bytes do Zip
		 *
		 * Utilize [caminhoZIP] para ver o arquivo fisico
		 * Utilize [null] para NAO gerar o arquivo fisico, somente o buffer.
		 */
		//FileOutputStream caminhoZIPDinamic = new FileOutputStream(new File(rootFolder + caminhoZIP));
		String zipBase64 = gerarZIP(pdfByteArrayStream, null);//caminhoZIPDinamic ou null

		/*
		 * Gera um ZIP apartir de um PDF existente.
		 *
		 * Utilize [caminhoZIPFisico] para ver o arquivo fisico
		 * Utilize [null] para NAO gerar o arquivo fisico, somente o buffer.
		 */
		//FileOutputStream caminhoZIPFisico = new FileOutputStream(new File(rootFolder + caminhoZIPFixo));
		String caminhoPDFOriginal = rootFolder + caminhoPDFFixo;
		String zipBase64PDFFisico = gerarArquivosFisicos(caminhoPDFOriginal, null);//caminhoZIPFisico ou  null

		/*
		 * Loggggging para analise
		 */
		synchronized (System.out) {
			loggingAnaliseBuffer(zipBase64, pdfByteArrayStream, arquivoNovosValores);//zip + pdf
			loggingAnaliseBuffer(zipBase64PDFFisico, null, null);//pdf fisco
		}

		return zipBase64;
	}

	  private void loggingAnaliseBuffer(String zipBase64, ByteArrayOutputStream pdf, StringBuffer htmlString) throws IOException {
		/*
		 * Metodo utilitario para visualizar os buffers criados
		 * Loggggging para analise
		 */
		if(htmlString!=null && htmlString.length() > 0) {
			byte[] byteArray = htmlString.toString().getBytes();
			String htmlBase64 = Base64.encodeBytes(byteArray);
			System.out.println("\nHTML Tamanho: " + htmlBase64.length() + " caracteres.\n" + htmlBase64.replaceAll("\n", ""));
		}
		if(pdf!=null) {
			byte[] array = pdf.toByteArray();
				  pdf.flush();
				  pdf.close();
			String pdfBase64 = Base64.encodeBytes(array);
			System.out.println("\nPDF Tamanho: " + pdfBase64.length() + " caracteres.\n" + pdfBase64.replaceAll("\n", ""));
		}
		if (zipBase64!=null && zipBase64.length() > 500) {//maior que somente o cabecalho
			System.out.println("\nZIP Tamanho: " + zipBase64.length() + " caracteres.\n" + zipBase64.replaceAll("\n", ""));
		}
	}

	/*
	 * Procura por token no HTML e substitui por valores reais da aplicacao.
	 */
	private StringBuffer replaceConteudo(StringBuffer htmlReplaceConteudo) throws Exception {
		
		Map<String, String> map = new HashMap<String, String>();
		/*
		 * Uma opcao para colocar valores dinamicos no HTML Fisico.
		 * Defini % como um caracter de identificacao.
		 *
		 */
		final String properties = rootFolder + "\\META-INF\\templates\\contratacao\\comprovante.properties";
		Map<String, String> propertiesMap = loadMappingProperties(properties);
		for (Entry<String, String> entry : propertiesMap.entrySet()) {
			//System.out.println( "["+entry.getKey() +" = "+ entry.getValue() +"]" );
			map.put(entry.getKey(), entry.getValue());
		}
		
		/*
		 * Caso tenha um bean mapeado poderia fazer algo assim
		 */
		MockDadosSegurado mock = new MockDadosSegurado();
		DadosSeguradoVO vo = mock.getDados();
		map.put("%SEGURADO_CPF", vo.getCpf());
		map.put("%SEGURADO_AGENCIA", vo.getAgencia());
		/*
		 * Replace conteudo no HTML com os Dados da Contratacao
		 * Nos casos abaixo posso ter 1 ou ate 5 beneficiarios, logo tive que criar o html neste metodo.
		 */
		ArrayList<Beneficiario> lista = vo.getBeneficiario();
		if(lista.isEmpty()) {
			map.put("%BENEF_CABECALHO", "<tr><td><p><strong>N�o informado</strong></p></td></tr>"); }
		else {
			map.put("%BENEF_CABECALHO", "<tr><td><p><strong>Nome</strong></p></td><td><p><strong>Parentesco</strong></p></td><td><p><strong>Percentual</strong></p></td></tr>");
			int i = 0;
			for (Beneficiario beneficiario : lista) {
				map.put("%BENEF_"+ ++i +"_NOME", "<tr><td><p>"+beneficiario.getNome()+"</p></td><td><p>"+beneficiario.getParentesco()+"</p></td><td><p>"+beneficiario.getPercentual()+" %</p></td></tr>");
			}
		}
		
		//Valores que nao podemos colocar nos properties
		SimpleDateFormat simple = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		map.put("%DATA_CONTRATACAO", simple.format(new Date()));
		map.put("%ROOT_FOLDER", rootFolder.replace("\\", "/"));

		for (Entry<String, String> entry : map.entrySet()) {
			//Note that backslashes (\) and dollar signs ($) in the replacement string may cause the results to be different 
			htmlReplaceConteudo = new StringBuffer(htmlReplaceConteudo.toString().replaceAll(entry.getKey(), entry.getValue()));
		}

		System.out.println(htmlReplaceConteudo);
		return htmlReplaceConteudo;
	}

	private Map<String, String> loadMappingProperties(String properties) throws Exception {
		
		Map<String, String> map = new HashMap<String, String>();
		try {
			Properties props = new Properties();
			FileInputStream file;
			file = new FileInputStream(properties);
			props.load(file);
			Enumeration<String> enums = (Enumeration<String>) props.propertyNames();
		    while (enums.hasMoreElements()) {
		      String key = enums.nextElement();
		      String value = props.getProperty(key);
		      map.put(key, value);
		    }
		} catch (Exception e) {
			throw new Exception(e);
		}
		return map;
	}

	private StringBuffer carregaArquivosFisicos(String caminhoHTML) throws Exception {
		StringBuffer buffer = new StringBuffer();
		try {
			InputStream inHTML = new FileInputStream(caminhoHTML);
			int content;
			while ((content = inHTML.read()) != -1) {
				buffer.append((char)content);
			}
			inHTML.close();
		} catch (Exception e) {
			throw new Exception(e);
		}
		return buffer;
	}

	/**
	 * Gerar ZIP apartir de um PDF Bufferizado
	 * @param ByteArrayOutputStream byteArrayOutputStream
	 * @return ByteArrayOutputStream byteArrayOutputStream
	 * @throws Exception
	 */
	public String gerarZIP(ByteArrayOutputStream byteArrayOutputStream, FileOutputStream caminhoZip) throws Exception {

		ByteArrayOutputStream destinoBuffer = null;
		String zipBase64 = null;
		try {
			if(byteArrayOutputStream.size() == 0) {
				System.out.println("\nZIP : Foi escolhido a saida fisica do PDF, logo o buffer zip64bits nao sera gerado, altere em PdfWriter.getInstance(document, bufferarrayoutputstream);");
			}
			final int TAMANHO_BUFFER_BYTES = 4096; // 4kb
			InputStream inputStreamEntrada = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
			BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStreamEntrada, TAMANHO_BUFFER_BYTES);

			ZipOutputStream zipOutputStream = null;
			if(caminhoZip!=null) {
				BufferedOutputStream destinoArquivo = new BufferedOutputStream(caminhoZip);
				// Use {destinoArquivo} para visualiza-lo na pasta src.
				zipOutputStream = new ZipOutputStream(destinoArquivo);
			}else {
				destinoBuffer = new ByteArrayOutputStream();
				// Use {destinoBuffer} para gerar Internamente.
				zipOutputStream = new ZipOutputStream(destinoBuffer);
			}

			// Defina um nome de como o pdf vai ficar dentro do zip, invisivel ao cliente.
			ZipEntry entry = new ZipEntry("comprovante_bradesco.pdf");
			if (!entry.isDirectory()) {
				zipOutputStream.putNextEntry(entry);
			}
			int cont;
			byte[] dados = new byte[TAMANHO_BUFFER_BYTES];
			while ((cont = bufferedInputStream.read(dados, 0, TAMANHO_BUFFER_BYTES)) != -1) {
				zipOutputStream.write(dados, 0, cont);
			}

			inputStreamEntrada.close();
			bufferedInputStream.close();
			zipOutputStream.close();
		} catch (Exception e) {
			throw new Exception(e);
		}

		/*
		 * Converte para String o Buffer Zip Array.
		 */
		if (destinoBuffer!=null) {
			byte[] array = destinoBuffer.toByteArray();
			zipBase64 = Base64.encodeBytes(array);
		} else {
			System.out.println("\nZIP: Foi escolhida a saida para a pasta fisica, arquivo gerado em: " + rootFolder + caminhoZIP);
		}

		return zipBase64;
	}

}
