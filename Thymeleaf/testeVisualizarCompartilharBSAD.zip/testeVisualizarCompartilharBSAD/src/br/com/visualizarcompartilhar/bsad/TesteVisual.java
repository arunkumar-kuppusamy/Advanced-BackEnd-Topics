package br.com.visualizarcompartilhar.bsad;

public class TesteVisual {

	public static String pdfBase64;
	public static ContratacaoAppViewBean contratacaoAppViewBean = new ContratacaoAppViewBean();

	public static void main(String[] args) {
		
		VISUAL compartilhar = new VISUAL();
		try {
			//Gera um ZIP apartir de um HTML existente
			//String pdfCondicoesGerais = compartilhar.pdfCondicoesGerais;
			//pdfBase64 = compartilhar.gerarArquivosFisicos(pdfCondicoesGerais, null).replaceAll("\n", "");

			//String templateTermosAceite = compartilhar.templateTermosAceite2;
			//pdfBase64 = compartilhar.gerarArquivos(templateTermosAceite, contratacaoAppViewBean).replaceAll("\n", "");
			
			String templateComprovanteAPP = compartilhar.templateComprovanteAPP;
			pdfBase64 = compartilhar.gerarArquivos(templateComprovanteAPP, contratacaoAppViewBean).replaceAll("\n", "");
			
			System.out.println("\n[ZIP DINAMICO]: " + pdfBase64);

			
		} catch (Exception e) {
			System.out.println("Ocorreu um erro ao gerar o visualizar e compartilhar.\n" + e );
		}
		System.out.println("Sucesso ao processar o m�todo [viewTermosAceite].");	
	}  

}
