package br.com.visualizarcompartilhar.bsad;

import java.util.ArrayList;
import java.util.List;

public class ContratacaoAppViewBean {

	
	List<BeneficiarioVO> vo = new ArrayList<BeneficiarioVO>();
	
	public List<BeneficiarioVO> getBeneficiarios() {
		
		BeneficiarioVO beneficiario = new BeneficiarioVO();
		beneficiario.setNome("Jos� da Silva dos Santos");
		beneficiario.setDescGrauParentesco("Pai");
		beneficiario.setPercentualParticipacao("20");
		vo.add(beneficiario);
		
		beneficiario = new BeneficiarioVO();
		beneficiario.setNome("Maria da Silva dos Santos");
		beneficiario.setDescGrauParentesco("M&#227;e");
		beneficiario.setPercentualParticipacao("20");
		vo.add(beneficiario);
		
		beneficiario = new BeneficiarioVO();
		beneficiario.setNome("Guilherme Amorim Filho");
		beneficiario.setDescGrauParentesco("Filho(a)");
		beneficiario.setPercentualParticipacao("20");
		vo.add(beneficiario);
		
		beneficiario = new BeneficiarioVO();
		beneficiario.setNome("Joana Bahia");
		beneficiario.setDescGrauParentesco("Irm&#227;o(a)");
		beneficiario.setPercentualParticipacao("20");
		vo.add(beneficiario);
		
		beneficiario = new BeneficiarioVO();
		beneficiario.setNome("Uelington Moraes de Almeida");
		beneficiario.setDescGrauParentesco("C&#244;njuge");
		beneficiario.setPercentualParticipacao("20");
		vo.add(beneficiario);
		
		return vo;
	}

}
