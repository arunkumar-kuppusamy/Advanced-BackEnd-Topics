package br.com.visualizarcompartilhar.bsad;

public class BeneficiarioVO {

	private String nome;
	private String descGrauParentesco;
	private String percentualParticipacao;
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDescGrauParentesco() {
		return descGrauParentesco;
	}
	public void setDescGrauParentesco(String descGrauParentesco) {
		this.descGrauParentesco = descGrauParentesco;
	}
	public String getPercentualParticipacao() {
		return percentualParticipacao;
	}
	public void setPercentualParticipacao(String percentualParticipacao) {
		this.percentualParticipacao = percentualParticipacao;
	}


}
