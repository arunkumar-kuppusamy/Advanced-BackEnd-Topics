package br.com.visualizarcompartilhar.core;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.nio.charset.Charset;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;
import org.w3c.dom.Document;
import org.w3c.tidy.Tidy;
import org.xhtmlrenderer.pdf.ITextRenderer;

import com.lowagie.text.pdf.codec.Base64;


/**
 * Classe para processar os arquivos no formato PDF
 * 
 * @author rcirino@scopus.com.br
 *
 */
public class SalvarComoArquivoPDF {


	protected static final String encoding_UTF_8 = "UTF-8";
	protected static final String encoding_ISO88591 = "ISO-8859-1";

	/**
	 * Criar PDF apartir de html fornecido
	 * @param String htmlParaConversao
	 * @return ByteArrayOutputStream byteArrayOutputStream
	 */
	public ByteArrayOutputStream processarArquivoVisual(ByteArrayInputStream byteArrayInput) {
		ByteArrayOutputStream byteArrayOutputStream = null;

			byteArrayOutputStream = new ByteArrayOutputStream();
			try {
				// Seta atributos de tidy para criacao de documento a partir de HTML
				Tidy tidy = new Tidy();
				tidy.setShowErrors(0);
				tidy.setShowWarnings(true);
				tidy.setQuiet(true);
				tidy.setInputEncoding(encoding_UTF_8);
				tidy.setOutputEncoding(encoding_UTF_8);
				tidy.setPrintBodyOnly(true);
				tidy.setSmartIndent(true);
				tidy.setJoinStyles(true);

				// Cria documento a partir de HTML
				Document doc = tidy.parseDOM(byteArrayInput, null);

				ITextRenderer renderer = new ITextRenderer();

				// Cria PDF
				renderer.setDocument(doc, null);
				renderer.layout();
				renderer.createPDF(byteArrayOutputStream);

			} catch (Exception e) {
				e.printStackTrace();
			}

			/*
			 * Loggggging para analise 
			 */
			if (byteArrayOutputStream!=null) {
				byte[] array = byteArrayOutputStream.toByteArray();
				String pdfBase64 = Base64.encodeBytes(array);
				System.out.println("\nPDF Tamanho: " + pdfBase64.length() + " caracteres.\n" + pdfBase64.replaceAll("\n", ""));
			}

		return byteArrayOutputStream;
	}

	/**
	 * Criar zip apartir de pdf fornecido
	 * @param ByteArrayOutputStream byteArrayOutputStream
	 * @return ByteArrayOutputStream byteArrayOutputStream
	 */
	public ByteArrayOutputStream gerarZIP(ByteArrayOutputStream byteArrayOutputStream, FileOutputStream caminhoZip) {

		ByteArrayOutputStream destinoBuffer = null;
		try {
			final int TAMANHO_BUFFER_BYTES = 4096; // 4kb
			InputStream inputStreamEntrada = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
			BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStreamEntrada, TAMANHO_BUFFER_BYTES);
			
			ZipOutputStream zipOutputStream = null;
			if(caminhoZip!=null) {
				BufferedOutputStream destinoArquivo = new BufferedOutputStream(caminhoZip);
				// Use {destinoArquivo} para visualiza-lo na pasta src.
				zipOutputStream = new ZipOutputStream(destinoArquivo);
			}else {
				destinoBuffer = new ByteArrayOutputStream();
				// Use {destinoBuffer} para gerar Internamente.
				zipOutputStream = new ZipOutputStream(destinoBuffer);
			}

			// Defina um nome de como o pdf vai ficar dentro do zip
			ZipEntry entry = new ZipEntry("comprovanteCliente.pdf");
			if (!entry.isDirectory()) {
				zipOutputStream.putNextEntry(entry);
			}
			int cont;
			byte[] dados = new byte[TAMANHO_BUFFER_BYTES];
			while ((cont = bufferedInputStream.read(dados, 0, TAMANHO_BUFFER_BYTES)) != -1) {
				zipOutputStream.write(dados, 0, cont);
			}
			
			inputStreamEntrada.close();
			bufferedInputStream.close();
			zipOutputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return destinoBuffer;
	}

	/**
	 * Carrega na memoria o template html
	 * @param String caminhoArquivoHTML
	 * @return String bufferHTML
	 */
	public String carregarTemplateHTML(String caminhoArquivoHTML) {

		StringBuffer bufferHTML = new StringBuffer();
		try {
			File file = new File(caminhoArquivoHTML);
			BufferedReader bufferReader = new BufferedReader(
					new InputStreamReader(new FileInputStream(file), Charset.forName(encoding_UTF_8)));

			String line = "";
			while ((line = bufferReader.readLine()) != null) {
				bufferHTML.append(line);
			}
			bufferReader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bufferHTML.toString();
	}

	/**
	 * Carrega na memoria o template em thymeleaf.
	 * @param String caminhoArquivoHTML
	 * @return String bufferHTML
	 */
	public String carregarTemplateEngine(String caminhoTemplateDinamico, Context contextVariables) {

		Context context = contextVariables;
		if(contextVariables == null) {
			context = new Context();
		}
		ClassLoaderTemplateResolver resolver = new ClassLoaderTemplateResolver();
		resolver.setTemplateMode("HTML");
		resolver.setSuffix(".html");
		TemplateEngine engine = new TemplateEngine();
		engine.setTemplateResolver(resolver);

		StringWriter writer = new StringWriter();
		engine.process(caminhoTemplateDinamico, context, writer);
		StringBuffer stringBuffer = writer.getBuffer();
		
		return stringBuffer.toString();
	}

}
