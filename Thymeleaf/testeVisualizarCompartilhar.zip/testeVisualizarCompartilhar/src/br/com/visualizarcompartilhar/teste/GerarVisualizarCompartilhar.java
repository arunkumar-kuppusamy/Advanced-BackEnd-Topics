package br.com.visualizarcompartilhar.teste;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.thymeleaf.context.Context;

import com.lowagie.text.pdf.codec.Base64;

import br.com.visualizarcompartilhar.bean.DadosSeguradoVO;
import br.com.visualizarcompartilhar.bean.MockDadosSegurado;
import br.com.visualizarcompartilhar.core.SalvarComoArquivoPDF;


public class GerarVisualizarCompartilhar {


	public static void main(String[] args) throws IOException {
	
		try {
			System.out.println("Inciando Visualizar e Compartihar.");
			GerarVisualizarCompartilhar g = new GerarVisualizarCompartilhar();
			String pdfBase64 = g.gerarArquivos();
			
			if(pdfBase64!=null)
				System.out.println("\nZIP Tamanho: " + pdfBase64.length() + " caracteres.\n" + pdfBase64.replaceAll("\n", ""));

			/*
			 * Enviar a tela a variavel pdfBase64, e setar num inputHidden obrigatoriamente com o identificador [id=pdfBase64]. 
			 */
				//<input type="hidden" id="pdfBase64" value="${pdfBase64}" />
			/*
			 * Criar dois bot�es nesta tela
			*/
				//<button onclick="javascript:enviarPDFEmbarcada('visualizarComprovante');">Visualizar</button>
				//<button onclick="javascript:enviarPDFEmbarcada('baixarComprovante');">Baixar/Compartilhar</button>
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * Gerar Aquivos
	 * Todas as rotinhas necessarias para gerar os arquivos. 
	 */
	public String gerarArquivos() throws Exception {
		
		String pdfBase64 = null;
		final String encoding_UTF_8 = "UTF-8";
		File resourcesDirectory = new File("src");
		final String template = resourcesDirectory.getAbsolutePath();
		final SalvarComoArquivoPDF salvar = new SalvarComoArquivoPDF();

		try {
			/*
			 * Carrega de um arquivo html dinamico
			 * 
			 * Context context: contem as variaveis que serao usadas na tela pelo Thymeleaf.
			 */
			Context context = this.carregarContexto();
			//final String caminhoTemplateDinamico = "\\META-INF\\templates\\contratacao\\termos-aceite";//extensao .HTML
			final String caminhoTemplateDinamico = "\\META-INF\\templates\\contratacao\\termos-aceite-opcao2";
			String htmlDinamico = salvar.carregarTemplateEngine(caminhoTemplateDinamico, context);
			System.out.println(htmlDinamico);
			
			/*
			 * Gera um ZIP apartir de um PDF existente.
			 *  
			 * Utilize [caminhoPdfZip] para ver o arquivo fisico
			 * Utilize [null] para NAO gerar o arquivo fisico, somente o buffer.
			 */
			FileOutputStream caminhoPdfZip = new FileOutputStream(new File(template + "\\META-INF\\templates\\output\\condicoes-gerais.zip"));
			String caminhoRelativoPdf = "\\META-INF\\templates\\contratacao\\app-condicoes-gerais.pdf";
			final int TAMANHO_BUFFER_BYTES = 8192;//4096 ou 8192;
			InputStream inputStreamEntrada = this.getClass().getClassLoader().getResourceAsStream(caminhoRelativoPdf);
			byte[] buffer = new byte[TAMANHO_BUFFER_BYTES];
			int bytesRead;
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
		    while ((bytesRead = inputStreamEntrada.read(buffer)) != -1) {
		    	byteArrayOutputStream.write(buffer, 0, bytesRead);
		    }
		    ByteArrayOutputStream zipBufferOutput = salvar.gerarZIP(byteArrayOutputStream, caminhoPdfZip);//caminhoPdfZip ou null

			/*
			 * Gera Stream 64 bytes do HTML
			 * Gera um PDF do HTML
			 * Gera um Zip do PDF
			 * Gera um Stream 64 bytes do Zip 
			 * 
			 * Utilize [caminhoHtmlZip] para ver o arquivo fisico
			 * Utilize [null] para NAO gerar o arquivo fisico, somente o buffer.
			 */
			FileOutputStream caminhoHtmlZip = new FileOutputStream(new File(template + "\\META-INF\\templates\\output\\comprovanteResultado.zip"));
			byte htmlBytes [] = htmlDinamico.getBytes(encoding_UTF_8);//{htmlDinamico} ou {htmlFIXO}
			ByteArrayInputStream byteArrayInput = new ByteArrayInputStream(htmlBytes);
			ByteArrayOutputStream byteArrayOutput = salvar.processarArquivoVisual(byteArrayInput);
			zipBufferOutput = salvar.gerarZIP(byteArrayOutput, null);//caminhoHtmlZip ou null
			
			/*
			 * Loggggging para analise
			 */
			if (zipBufferOutput!=null) {
				byte[] array = zipBufferOutput.toByteArray();
				pdfBase64 = Base64.encodeBytes(array);
			} else {
				System.out.println("Foi escolhida a saida para a pasta fisica, arquivo gerado em: " + template);
			}

			/*
			 * Bloco para testes, gerando um arquivo PDF fisico 
			 */
			FileOutputStream fileOutput = new FileOutputStream(new File(template + "\\META-INF\\templates\\output\\app_contratacao_comprovante.pdf"));
			byteArrayOutput.writeTo(fileOutput);
			fileOutput.flush();
			fileOutput.close();		
			
			//Fecha os streams
			byteArrayInput.close();
			byteArrayOutput.flush();
			byteArrayOutput.close();
			caminhoHtmlZip.flush();
			caminhoHtmlZip.close();
			caminhoPdfZip.flush();
			caminhoPdfZip.close();
			if(zipBufferOutput!=null)zipBufferOutput.flush();
			if(zipBufferOutput!=null)zipBufferOutput.close();

		}catch(Exception e) {
			//NullPointer se a saida for fisica mas buffer esta sendo feito flush e close.
			throw new Exception(e);
		}
		
		return pdfBase64;
	}
	
	private Context carregarContexto() throws ParseException {
		Context context = new Context();

		context.setVariable("nomeAplicacao", "ACIDENTES PESSOAIS PREMI�VEL");
		context.setVariable("nomeProduto", "ACIDENTES PESSOAIS PREMI�VEL");

		MockDadosSegurado mock = new MockDadosSegurado();
		DadosSeguradoVO comprovante = mock.getDados();
		context.setVariable("comprovante", comprovante);
		
		return context;
	}
	
}
