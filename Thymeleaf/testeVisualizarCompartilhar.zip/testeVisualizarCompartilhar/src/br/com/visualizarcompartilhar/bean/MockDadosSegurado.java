package br.com.visualizarcompartilhar.bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MockDadosSegurado {

	public DadosSeguradoVO getDados() throws ParseException {
		DadosSeguradoVO vo = new DadosSeguradoVO();
		vo.setNomeSegurado("FLAVIA SILVA FERRAO");
		vo.setProtocolo("016820180615000000000000073705");
		vo.setDataContratacao(new Date());
		vo.setModulos("2");
		vo.setCobertura("R$ 50.000,00");
		vo.setCpf("987.241.597-86");
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
		Date dataUsuario = sdf1.parse("12/12/2000");
		vo.setDataNascimento("12/12/2000");
		vo.setProfissao("69 - ANALISTA DE SISTEMAS");
		vo.setRenda("De 8.001 at� 10.000");
		vo.setSexo("MASCULINO");
		vo.setCep("26062-420");
		vo.setRua("Rua Am�rico Vesp�cio");
		vo.setNumero("552");
		vo.setComplemento("Torre Norte");
		vo.setBairro("Cidade Jardim Parque Estoril");
		vo.setCidade("Nova Igua�u");
		vo.setEstado("RJ");
		vo.setTelefone("(11) 3236-0023");
		vo.setEmail("emailteste@teste.com.br");
		vo.setBanco("237");
		vo.setAgencia("241");
		vo.setConta("60060-6");
		vo.setTipoConta("Conta Corrente");
		// vo.setBeneficiario("");
		vo.setPremioPeriodo("R$ 8,41");
		vo.setIof("R$ 0,03");
		vo.setPremioTotal("R$ 8,44");

		ArrayList<Beneficiario> lista = new ArrayList<Beneficiario>();
		Beneficiario ben = new Beneficiario();
		ben.setNome("Jos� da Silva Santos");
		ben.setParentesco("Pai");
		ben.setPercentual("50 %");
		lista.add(ben);
		ben = new Beneficiario();
		ben.setNome("Maria da Silva Santos");
		ben.setParentesco("Filho (a)");
		ben.setPercentual("50 %");
		lista.add(ben);
		vo.setBeneficiario(lista);

		return vo;
	}
}