2function enviarPDFEmbarcada(opcao) {

	var tecnologia = getTecnologia();
	var pdfBase64 = jQuery("#pdfBase64").val();

	if (tecnologia == "android") {
		if (opcao == "visualizarComprovante") {
			jsinterface.visualizarComprovante(pdfBase64);
		} else if (opcao == "baixarComprovante") {
			jsinterface.baixarComprovante(pdfBase64);
		}
	} else if (tecnologia == "iphone") {
		if (opcao == "visualizarComprovante") {
			window.location = "ios://visualizarComprovante";
		} else if (opcao == "baixarComprovante") {
			window.location = "ios://baixarComprovante";
		}
	}
}

function getTecnologia() {

	var iphoneRender = "iphone";
	var ipadRender = "ipad";
	var androidRender = "android";
	var winMobileRender = "iemobile";
	var userAgent = navigator.userAgent.toLowerCase();
	var tecnologia;

	if (userAgent.indexOf(iphoneRender) > -1
			|| userAgent.indexOf(ipadRender) > -1) {
		tecnologia = "iphone";
	} else if (userAgent.indexOf(androidRender) > -1) {
		tecnologia = "android";
	} else if (userAgent.indexOf(winMobileRender) > -1) {
		tecnologia = "winmobile";
	} else {
		tecnologia = "android";
	}

	return tecnologia;
}

function recuperaPdfIOS(){
	return jQuery("#pdfBase64").val();
}
